
Chebyshev’s Rule

Chebyshev’s Rule
For any quantitative data set and any real number k greater than or equal to 1, at least 1 − 1/k2 of the observations lie within k standard deviations to either side of the mean, that is, between x¯ − k · s and x¯ + k · s.


![[Pasted image 20221109163609.png]]
Chebyshev’s rule with k = 2 and k = 3

![[Pasted image 20221109163935.png]]